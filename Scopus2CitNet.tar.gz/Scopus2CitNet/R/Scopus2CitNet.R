#' Scopus2CitNet
#'
#' Transforms Scopus Dataframes into Files Readable in CitNetExplorer
#' @param dataframe from a Scopus file
#' It must contain these columns: Authors (1st column), Title, Year, Source title, Volume, Cited by, References
#' @return a .csv file that shall be readable in CitNetExplorer
#' VAN ECK N.J. & WALTMAN L. (2014) www.citnetexplorer.nl
#' @keywords Scopus, bibliometrics
#' @export
#' @examples
#' scopus <- read.table(file = "scopus.csv", sep = ",", na = "NA", header = T, encoding = "UTF-8")
#' Scopus2CitNet(scopus)

Scopus2CitNet <- function(a){
colnames(a)[1] <- "Authors" #Shall correct the column name for first undesired characters due to encoding
s <- a$Authors
t <- a$Title
u <- a$Year
v <- a$Source.title
w <- a$Volume
x <- a$Cited.by
y <- a$References
#Ad hoc DOIs will be produced whereas those in the original document will not be made use of #DI

#Cleansing
s <- gsub(";", ",", s)
t <- gsub(";", ",", t)
v <- gsub(";", ",", v)
y <- gsub(";", ",", y)

s <- gsub("\"", "", s)
t <- gsub("\"", "", t)
v <- gsub("\"", "", v)
y <- gsub("\"", "", y)

s <- gsub("\'", "", s)
t <- gsub("\'", "", t)
v <- gsub("\'", "", v)
y <- gsub("\'", "", y)

#Fills the potential empty cells in "s", "u" and "v" otherwise CitNet cannot run
s <- sub("^$", "Not Available", s)
u <- sub("^$", "1900", u) #1900 means the date is "Not Available"
v <- sub("^$", "Not Available", v)

#Transforms column "w" into a vector as other columns have become after gsub function
w <- as.vector(w)

#Deletes all "|" before determining it as de facto optimal separator
y <- gsub("[|]", "", y)
y <- gsub("[(]", "|", y)
y <- gsub("[)]", "|", y)
y <- gsub("[.][,]", "|", y)
y <- gsub("pp.", "|", y)
y <- gsub(", ,", "|", y)
y <- gsub("[0-9]","|", y)

#Determining a rare string so as to reuse it as separator after cleaning all punctuation marks
y <- gsub("[|]", "tirelipimpon", y)

y <- gsub("[[:punct:]]", "", y)
y <- gsub("[[:blank:]]", "", y)
y <- tolower(y)

y <- gsub("tirelipimpon", ",", y)

#Generating a new variable based on titles with the aim of producing new DOIs
z <- gsub("[[:punct:]]", "", t)
z <- gsub("[[:blank:]]", "", z)
z <- tolower(z)

#Creation of new DOIs based on titles
n1 <- mean(nchar(z)) - 1.96*sd(nchar(z)) #minimal number (ideally above 21 for short titles have a higher probability to be not related)
n1 <- ifelse(n1 > 21, n1, 21)
n2 <- mean(nchar(z)) + 1.96*sd(nchar(z)) #maximal number (both boundaries n1 and n2 should encompass around 95% of the distribution)
n1 <- round(n1)
n2 <- round(n2)
z <- ifelse(nchar(z) > n1, z, "expression_to_replace_strings_that_are_less_than_n1") #this expression shouldn't correspond to anything ;-)
z <- ifelse(nchar(z) < n2, z, "expression_to_replace_strings_that_are_more_than_n2") #this expression shouldn't correspond to anything ;-)
y <- gsub(paste0("\\b\\w{1,",n1,"}\\b"), "", y) #deletes all strings equal to or smaller than n1 (by default)
y <- gsub(paste0("\\b\\w{",n2,"}\\b"), "", y) #deletes all strings equal to or bigger than n2 (by default)
y <- gsub(",", " ", y)
y <- gsub("\\s+", ",", y)
dup <- duplicated(z)

#Creation of a new data base
df <- as.data.frame(cbind(s,t,u,v,w,x,z,y,dup))
names <- c("AU", "TI", "PY", "SO", "VL", "BP", "DI", "CR", "dup")
colnames(df) <- names
df <- df[!(df$dup=="TRUE"),] #deletes the duplicates
df <- df[1:8]
au.vec <- gsub(",", "", df$AU)
ti.vec <- as.vector(df$TI)
py.vec <- as.vector(df$PY)
so.vec <- as.vector(df$SO)
vl.vec <- as.vector(df$VL)
bp.vec <- as.vector(df$BP)
di.vec <- as.vector(paste0("10.",df$DI))
df[,7] <- di.vec
cr.vec <- as.vector(df$CR)
cr.spl <- strsplit(cr.vec, ",")
paste.1 <- paste0(au.vec,", ",py.vec,", ",so.vec,", ",vl.vec,", ",bp.vec,", DOI ",di.vec)
paste.2 <- cbind(DI = as.character(df$DI), paste.1)
df.cbind <- cbind(AU = rep(au.vec, sapply(cr.spl, length)),
                  TI = rep(ti.vec, sapply(cr.spl, length)),
                  PY = rep(py.vec, sapply(cr.spl, length)),
                  SO = rep(so.vec, sapply(cr.spl, length)),
                  VL = rep(vl.vec, sapply(cr.spl, length)),
                  BP = rep(bp.vec, sapply(cr.spl, length)),
                  DI = rep(di.vec, sapply(cr.spl, length)),
                  CR = paste0("10.",unlist(cr.spl))
                  )
df.cbind <- df.cbind[!(df.cbind[,8]=="10."),]

for(i in 1:nrow(paste.2)){
  df.cbind[,8][df.cbind[,8] %in% paste.2[,1][i]] <- paste.2[,2][i]
}

agg <- aggregate(df.cbind[,8] ~ df.cbind[,7], df.cbind, paste0, collapse = "; ")
names(agg) <- c("DI", "CR")

dfm <- as.matrix(df)
ag <- as.matrix(agg)

for (i in 1:nrow(ag)){
  dfm[,8][dfm[,7] %in% ag[,1][i]] <- ag[,2][i]
}

write.table(dfm, file = "Scopus2CitNet.txt", sep = "\t", na = "NA", row.names = F)
}